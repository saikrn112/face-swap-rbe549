# Face Swapping - Project 2 - RBE549
Swap faces in the video using classical and deep learning approach
---

To Run the triangulation code 
```
python phase1_wrapper.py --display
```

To Run the TPS code 
```
python tps.py --display
```

## Collaborators 
Radha Saraf - rrsaraf@wpi.edu

Ramana - spinnamaraju@wpi.edu
